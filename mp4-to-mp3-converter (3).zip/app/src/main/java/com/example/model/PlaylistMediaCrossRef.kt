package com.example.model

import androidx.room.Entity

@Entity(
    tableName = "playlist_media_cross_ref",
    primaryKeys = ["playlistId", "mediaTrackId"]
)
data class PlaylistMediaCrossRef(
    val playlistId: Long,
    val mediaTrackId: Long,
    val orderIndex: Int
)
