package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "media_tracks")
data class MediaTrack(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uri: String,
    val title: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val lastPlaybackPosition: Long = 0L,
    val lastPlayedTimestamp: Long = 0L
)
