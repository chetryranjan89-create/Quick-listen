package com.example.service

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.example.database.MusicDao
import com.example.database.QuickListenDatabase
import com.example.model.MediaTrack
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class RepeatMode {
    OFF, ONE, ALL
}

object AudioPlaybackManager {
    private const val TAG = "AudioPlaybackManager"

    private var player: ExoPlayer? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    // UI state flows
    private val _playingTrack = MutableStateFlow<MediaTrack?>(null)
    val playingTrack: StateFlow<MediaTrack?> = _playingTrack.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _playbackPosition = MutableStateFlow(0L)
    val playbackPosition: StateFlow<Long> = _playbackPosition.asStateFlow()

    private val _playbackDuration = MutableStateFlow(0L)
    val playbackDuration: StateFlow<Long> = _playbackDuration.asStateFlow()

    private val _currentPlaylist = MutableStateFlow<List<MediaTrack>>(emptyList())
    val currentPlaylist: StateFlow<List<MediaTrack>> = _currentPlaylist.asStateFlow()

    private val _shuffleEnabled = MutableStateFlow(false)
    val shuffleEnabled: StateFlow<Boolean> = _shuffleEnabled.asStateFlow()

    private val _repeatMode = MutableStateFlow(RepeatMode.OFF)
    val repeatMode: StateFlow<RepeatMode> = _repeatMode.asStateFlow()

    // Sleep Timer states
    private val _sleepTimerSeconds = MutableStateFlow(0)
    val sleepTimerSeconds: StateFlow<Int> = _sleepTimerSeconds.asStateFlow()

    private val _stopAtTrackEnd = MutableStateFlow(false)
    val stopAtTrackEnd: StateFlow<Boolean> = _stopAtTrackEnd.asStateFlow()

    private var sleepTimerJob: Job? = null
    private var progressJob: Job? = null
    private var musicDao: MusicDao? = null

    fun getOrCreatePlayer(context: Context): ExoPlayer {
        val currentPool = player
        if (currentPool != null) return currentPool

        val newPlayer = ExoPlayer.Builder(context.applicationContext).build()
        player = newPlayer
        musicDao = QuickListenDatabase.getDatabase(context.applicationContext).musicDao()

        newPlayer.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                _isPlaying.value = newPlayer.isPlaying
                _playbackDuration.value = newPlayer.duration.coerceAtLeast(0L)
                
                if (state == Player.STATE_READY) {
                    _playbackDuration.value = newPlayer.duration
                } else if (state == Player.STATE_ENDED) {
                    handlePlaybackEnded(context)
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _isPlaying.value = isPlaying
                if (isPlaying) {
                    startProgressTracking()
                } else {
                    stopProgressTracking()
                }
            }

            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int
            ) {
                _playbackPosition.value = newPosition.positionMs
            }
        })

        startProgressTracking()
        return newPlayer
    }

    private fun handlePlaybackEnded(context: Context) {
        scope.launch {
            if (_stopAtTrackEnd.value && _sleepTimerSeconds.value > 0) {
                // Sleep Timer requested stop at end of track
                clearSleepTimer()
                performFadeOutAndPause()
            } else {
                when (_repeatMode.value) {
                    RepeatMode.ONE -> {
                        player?.seekTo(0)
                        player?.play()
                    }
                    RepeatMode.ALL -> {
                        skipNext(context)
                    }
                    RepeatMode.OFF -> {
                        val playlist = _currentPlaylist.value
                        val current = _playingTrack.value
                        if (playlist.isNotEmpty() && current != null) {
                            val nextIndex = playlist.indexOfFirst { it.id == current.id } + 1
                            if (nextIndex < playlist.size) {
                                playTrack(context, playlist[nextIndex], playlist)
                            } else {
                                _isPlaying.value = false
                            }
                        } else {
                            _isPlaying.value = false
                        }
                    }
                }
            }
        }
    }

    fun playTrack(context: Context, track: MediaTrack, playlist: List<MediaTrack>) {
        val playerInstance = getOrCreatePlayer(context)
        _currentPlaylist.value = playlist
        _playingTrack.value = track

        // Save last played timestamp inside Room for "Recently Played" shelf
        scope.launch(Dispatchers.IO) {
            musicDao?.let { dao ->
                val updatedTrack = track.copy(lastPlayedTimestamp = System.currentTimeMillis())
                dao.updateTrack(updatedTrack)
            }
        }

        playerInstance.stop()
        playerInstance.clearMediaItems()
        
        val mediaUri = Uri.parse(track.uri)
        val mediaItem = MediaItem.fromUri(mediaUri)
        playerInstance.setMediaItem(mediaItem)
        
        // Auto-resume from last saved position is required by prompt
        if (track.lastPlaybackPosition > 0L && track.lastPlaybackPosition < track.durationMs - 5000) {
            playerInstance.seekTo(track.lastPlaybackPosition)
        } else {
            playerInstance.seekTo(0)
        }

        playerInstance.prepare()
        playerInstance.playWhenReady = true
        playerInstance.play()

        _playbackDuration.value = track.durationMs
        _isPlaying.value = true
    }

    fun togglePlayPause() {
        val playerInstance = player ?: return
        if (playerInstance.isPlaying) {
            playerInstance.pause()
            saveLastPosition()
        } else {
            playerInstance.play()
        }
    }

    fun seekTo(positionMs: Long) {
        val playerInstance = player ?: return
        playerInstance.seekTo(positionMs)
        _playbackPosition.value = positionMs
        saveLastPosition()
    }

    fun skipNext(context: Context) {
        val playlist = _currentPlaylist.value
        val current = _playingTrack.value ?: return
        if (playlist.isEmpty()) return

        val currentIndex = playlist.indexOfFirst { it.id == current.id }
        if (currentIndex == -1) return

        if (_shuffleEnabled.value) {
            val randomIdx = (playlist.indices).random()
            playTrack(context, playlist[randomIdx], playlist)
        } else {
            val nextIndex = (currentIndex + 1) % playlist.size
            playTrack(context, playlist[nextIndex], playlist)
        }
    }

    fun skipPrevious(context: Context) {
        val playlist = _currentPlaylist.value
        val current = _playingTrack.value ?: return
        if (playlist.isEmpty()) return

        val currentIndex = playlist.indexOfFirst { it.id == current.id }
        if (currentIndex == -1) return

        val prevIndex = if (currentIndex - 1 < 0) playlist.size - 1 else currentIndex - 1
        playTrack(context, playlist[prevIndex], playlist)
    }

    fun toggleShuffle() {
        _shuffleEnabled.value = !_shuffleEnabled.value
    }

    fun toggleRepeatMode() {
        _repeatMode.value = when (_repeatMode.value) {
            RepeatMode.OFF -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.OFF
        }
    }

    // --- Sleep Timer Management ---
    fun startSleepTimer(seconds: Int, stopAtEnd: Boolean) {
        sleepTimerJob?.cancel()
        _sleepTimerSeconds.value = seconds
        _stopAtTrackEnd.value = stopAtEnd

        sleepTimerJob = scope.launch {
            while (_sleepTimerSeconds.value > 0) {
                delay(1000)
                _sleepTimerSeconds.value = _sleepTimerSeconds.value - 1
            }
            // Sleep Timer Finished
            if (_stopAtTrackEnd.value) {
                // Let the player reach state ENDED, wait for track end
            } else {
                performFadeOutAndPause()
            }
        }
    }

    fun clearSleepTimer() {
        sleepTimerJob?.cancel()
        _sleepTimerSeconds.value = 0
    }

    private suspend fun performFadeOutAndPause() {
        val playerInstance = player ?: return
        val originalVolume = playerInstance.volume
        val steps = 10
        val stepDelay = 300L

        for (i in 1..steps) {
            val volume = originalVolume * (steps - i) / steps
            playerInstance.volume = volume
            delay(stepDelay)
        }

        playerInstance.pause()
        saveLastPosition()
        playerInstance.volume = originalVolume // restore volume level
        _isPlaying.value = false
    }

    private fun saveLastPosition() {
        val playerInstance = player ?: return
        val currentTrack = _playingTrack.value ?: return
        val pos = playerInstance.currentPosition

        scope.launch(Dispatchers.IO) {
            musicDao?.let { dao ->
                val track = dao.getTrackById(currentTrack.id)
                if (track != null) {
                    dao.updateTrack(track.copy(lastPlaybackPosition = pos))
                }
            }
        }
    }

    private fun startProgressTracking() {
        progressJob?.cancel()
        progressJob = scope.launch {
            while (true) {
                player?.let { playerInstance ->
                    if (playerInstance.isPlaying) {
                        _playbackPosition.value = playerInstance.currentPosition
                        // Periodically sync position to Room to always preserve resume
                        if (System.currentTimeMillis() % 10000 < 1000) {
                            saveLastPosition()
                        }
                    }
                }
                delay(1000)
            }
        }
    }

    private fun stopProgressTracking() {
        progressJob?.cancel()
    }
}
