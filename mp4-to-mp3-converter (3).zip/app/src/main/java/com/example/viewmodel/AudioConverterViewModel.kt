package com.example.viewmodel

import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.database.MusicRepository
import com.example.database.QuickListenDatabase
import com.example.model.MediaTrack
import com.example.model.Playlist
import com.example.service.AudioPlaybackManager
import com.example.service.RepeatMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.text.DecimalFormat

class AudioConverterViewModel : ViewModel() {

    private val TAG = "AudioConverterViewModel"

    private var repository: MusicRepository? = null

    // Room collection flows
    private val _allTracksFlow = MutableStateFlow<List<MediaTrack>>(emptyList())
    val allTracks: StateFlow<List<MediaTrack>> = _allTracksFlow.asStateFlow()

    private val _recentlyPlayedFlow = MutableStateFlow<List<MediaTrack>>(emptyList())
    val recentlyPlayed: StateFlow<List<MediaTrack>> = _recentlyPlayedFlow.asStateFlow()

    private val _allPlaylistsFlow = MutableStateFlow<List<Playlist>>(emptyList())
    val allPlaylists: StateFlow<List<Playlist>> = _allPlaylistsFlow.asStateFlow()

    private val _playlistTracksFlow = MutableStateFlow<List<MediaTrack>>(emptyList())
    val playlistTracks: StateFlow<List<MediaTrack>> = _playlistTracksFlow.asStateFlow()

    private val _selectedPlaylistId = MutableStateFlow<Long?>(null)
    val selectedPlaylistId: StateFlow<Long?> = _selectedPlaylistId.asStateFlow()

    // Expose local player state flows
    val playingTrack: StateFlow<MediaTrack?> = AudioPlaybackManager.playingTrack
    val isPlaying: StateFlow<Boolean> = AudioPlaybackManager.isPlaying
    val playbackPosition: StateFlow<Long> = AudioPlaybackManager.playbackPosition
    val playbackDuration: StateFlow<Long> = AudioPlaybackManager.playbackDuration
    val shuffleEnabled: StateFlow<Boolean> = AudioPlaybackManager.shuffleEnabled
    val repeatMode: StateFlow<RepeatMode> = AudioPlaybackManager.repeatMode
    val sleepTimerSeconds: StateFlow<Int> = AudioPlaybackManager.sleepTimerSeconds
    val stopAtTrackEnd: StateFlow<Boolean> = AudioPlaybackManager.stopAtTrackEnd

    fun initDatabase(context: Context) {
        if (repository != null) return

        val database = QuickListenDatabase.getDatabase(context.applicationContext)
        val repo = MusicRepository(database.musicDao())
        repository = repo

        // Direct database collection to expose reactively to Compose
        viewModelScope.launch {
            repo.allTracks.collect { _allTracksFlow.value = it }
        }

        viewModelScope.launch {
            repo.recentlyPlayed.collect { _recentlyPlayedFlow.value = it }
        }

        viewModelScope.launch {
            repo.allPlaylists.collect { _allPlaylistsFlow.value = it }
        }

        // Keep tracks in the selected playlist updated
        viewModelScope.launch {
            _selectedPlaylistId.collect { id ->
                if (id != null) {
                    repo.getTracksForPlaylist(id).collect { _playlistTracksFlow.value = it }
                } else {
                    _playlistTracksFlow.value = emptyList()
                }
            }
        }
    }

    // --- File Import (SAF Picker) ---
    fun importSelectedFile(context: Context, uri: Uri, customName: String? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Grant persistent read access to picked Uri to play offline even after reboot
                try {
                    context.contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: Exception) {
                    Log.w(TAG, "Could not persist Uri read permission: ${e.message}")
                }

                val title = customName ?: getFileNameFromUri(context, uri)
                var durationMs = 0L
                var sizeBytes = 0L

                // 1. Resolve duration via MediaMetadataRetriever
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(context, uri)
                    val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    if (durationStr != null) {
                        durationMs = durationStr.toLong()
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error extracting duration via MediaMetadataRetriever: ${e.message}")
                } finally {
                    try { retriever.release() } catch (ignored: Exception) {}
                }

                // 2. Resolve file size via Content Resolver
                try {
                    context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                        val sizeCol = cursor.getColumnIndex(OpenableColumns.SIZE)
                        if (sizeCol != -1 && cursor.moveToFirst()) {
                            sizeBytes = cursor.getLong(sizeCol)
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error querying size: ${e.message}")
                }

                // Create and insert MediaTrack
                val track = MediaTrack(
                    uri = uri.toString(),
                    title = title,
                    durationMs = durationMs,
                    sizeBytes = sizeBytes
                )

                repository?.let { repo ->
                    val existing = repo.getTrackByUri(uri.toString())
                    if (existing == null) {
                        repo.insertTrack(track)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed importing picked media file: ${e.message}", e)
            }
        }
    }

    // --- Media Controls BRIDGE ---
    fun playTrack(context: Context, track: MediaTrack, playlist: List<MediaTrack>) {
        AudioPlaybackManager.playTrack(context, track, playlist)
    }

    fun togglePlayPause() {
        AudioPlaybackManager.togglePlayPause()
    }

    fun seekTo(positionMs: Long) {
        AudioPlaybackManager.seekTo(positionMs)
    }

    fun skipNext(context: Context) {
        AudioPlaybackManager.skipNext(context)
    }

    fun skipPrevious(context: Context) {
        AudioPlaybackManager.skipPrevious(context)
    }

    fun toggleShuffle() {
        AudioPlaybackManager.toggleShuffle()
    }

    fun toggleRepeatMode() {
        AudioPlaybackManager.toggleRepeatMode()
    }

    // --- Sleep Timer Settings ---
    fun startSleepTimer(minutes: Int, stopAtEnd: Boolean) {
        AudioPlaybackManager.startSleepTimer(minutes * 60, stopAtEnd)
    }

    fun stopSleepTimer() {
        AudioPlaybackManager.clearSleepTimer()
    }

    // --- Playlists Mutations ---
    fun createPlaylist(name: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository?.createPlaylist(name)
        }
    }

    fun deletePlaylist(playlistId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            if (_selectedPlaylistId.value == playlistId) {
                _selectedPlaylistId.value = null
            }
            repository?.deletePlaylist(playlistId)
        }
    }

    fun setSelectedPlaylist(playlistId: Long?) {
        _selectedPlaylistId.value = playlistId
    }

    fun addTrackToPlaylist(playlistId: Long, trackId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository?.addTrackToPlaylist(playlistId, trackId)
        }
    }

    fun removeTrackFromPlaylist(playlistId: Long, trackId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository?.removeTrackFromPlaylist(playlistId, trackId)
        }
    }

    // --- Track Mutations ---
    fun updateTrackTitle(track: MediaTrack, newTitle: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository?.updateTrack(track.copy(title = newTitle))
        }
    }

    fun deleteTrack(track: MediaTrack) {
        viewModelScope.launch(Dispatchers.IO) {
            // If deleting currently active track, stop player
            if (playingTrack.value?.id == track.id) {
                AudioPlaybackManager.seekTo(0L)
                AudioPlaybackManager.togglePlayPause()
            }
            repository?.deleteTrack(track)
        }
    }

    // --- Helper Formatters ---
    fun formatDuration(ms: Long): String {
        if (ms <= 0) return "00:00"
        val totalSeconds = ms / 1000
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return String.format("%02d:%02d", minutes, seconds)
    }

    fun formatSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val df = DecimalFormat("#.#")
        return when {
            bytes >= 1024 * 1024 * 1024 -> df.format(bytes / (1024.0 * 1024.0 * 1024.0)) + " GB"
            bytes >= 1024 * 1024 -> df.format(bytes / (1024.0 * 1024.0)) + " MB"
            bytes >= 1024 -> df.format(bytes / 1024.0) + " KB"
            else -> "$bytes B"
        }
    }

    private fun getFileNameFromUri(context: Context, uri: Uri): String {
        var result: String? = null
        if (uri.scheme == "content") {
            try {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val nameCol = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (nameCol != -1) {
                            result = cursor.getString(nameCol)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error looking up filename: ${e.message}")
            }
        }
        if (result == null) {
            result = uri.path
            val cut = result?.lastIndexOf('/') ?: -1
            if (cut != -1) {
                result = result?.substring(cut + 1)
            }
        }
        return result ?: "audio_file"
    }
}
