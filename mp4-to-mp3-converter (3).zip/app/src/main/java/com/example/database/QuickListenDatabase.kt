package com.example.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.model.MediaTrack
import com.example.model.Playlist
import com.example.model.PlaylistMediaCrossRef

@Database(
    entities = [
        MediaTrack::class,
        Playlist::class,
        PlaylistMediaCrossRef::class
    ],
    version = 1,
    exportSchema = false
)
abstract class QuickListenDatabase : RoomDatabase() {

    abstract fun musicDao(): MusicDao

    companion object {
        @Volatile
        private var INSTANCE: QuickListenDatabase? = null

        fun getDatabase(context: Context): QuickListenDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    QuickListenDatabase::class.java,
                    "quick_listen_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
