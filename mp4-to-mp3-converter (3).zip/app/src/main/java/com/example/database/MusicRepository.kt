package com.example.database

import com.example.model.MediaTrack
import com.example.model.Playlist
import com.example.model.PlaylistMediaCrossRef
import kotlinx.coroutines.flow.Flow

class MusicRepository(private val musicDao: MusicDao) {

    val allTracks: Flow<List<MediaTrack>> = musicDao.getAllTracksFlow()
    val recentlyPlayed: Flow<List<MediaTrack>> = musicDao.getRecentlyPlayedFlow()
    val allPlaylists: Flow<List<Playlist>> = musicDao.getAllPlaylistsFlow()

    fun getTracksForPlaylist(playlistId: Long): Flow<List<MediaTrack>> {
        return musicDao.getTracksForPlaylistFlow(playlistId)
    }

    suspend fun getTrackByUri(uri: String): MediaTrack? {
        return musicDao.getTrackByUri(uri)
    }

    suspend fun getTrackById(id: Long): MediaTrack? {
        return musicDao.getTrackById(id)
    }

    suspend fun insertTrack(track: MediaTrack): Long {
        return musicDao.insertTrack(track)
    }

    suspend fun updateTrack(track: MediaTrack) {
        musicDao.updateTrack(track)
    }

    suspend fun deleteTrack(track: MediaTrack) {
        musicDao.deleteTrack(track)
    }

    suspend fun createPlaylist(name: String): Long {
        return musicDao.insertPlaylist(Playlist(name = name))
    }

    suspend fun deletePlaylist(playlistId: Long) {
        musicDao.deleteCrossRefsForPlaylist(playlistId)
        musicDao.deletePlaylist(Playlist(id = playlistId, name = ""))
    }

    suspend fun addTrackToPlaylist(playlistId: Long, trackId: Long) {
        val nextIdx = musicDao.getNextOrderIndex(playlistId)
        musicDao.insertCrossRef(PlaylistMediaCrossRef(playlistId, trackId, nextIdx))
    }

    suspend fun removeTrackFromPlaylist(playlistId: Long, trackId: Long) {
        musicDao.deleteCrossRef(playlistId, trackId)
    }
}
