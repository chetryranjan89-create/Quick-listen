package com.example.database

import androidx.room.*
import com.example.model.MediaTrack
import com.example.model.Playlist
import com.example.model.PlaylistMediaCrossRef
import kotlinx.coroutines.flow.Flow

@Dao
interface MusicDao {

    // --- Media Tracks Queries ---
    @Query("SELECT * FROM media_tracks ORDER BY id DESC")
    fun getAllTracksFlow(): Flow<List<MediaTrack>>

    @Query("SELECT * FROM media_tracks WHERE uri = :uri LIMIT 1")
    suspend fun getTrackByUri(uri: String): MediaTrack?

    @Query("SELECT * FROM media_tracks WHERE id = :id LIMIT 1")
    suspend fun getTrackById(id: Long): MediaTrack?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrack(track: MediaTrack): Long

    @Update
    suspend fun updateTrack(track: MediaTrack)

    @Delete
    suspend fun deleteTrack(track: MediaTrack)

    @Query("SELECT * FROM media_tracks WHERE lastPlayedTimestamp > 0 ORDER BY lastPlayedTimestamp DESC LIMIT 30")
    fun getRecentlyPlayedFlow(): Flow<List<MediaTrack>>

    // --- Playlist Queries ---
    @Query("SELECT * FROM playlists ORDER BY name ASC")
    fun getAllPlaylistsFlow(): Flow<List<Playlist>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: Playlist): Long

    @Update
    suspend fun updatePlaylist(playlist: Playlist)

    @Delete
    suspend fun deletePlaylist(playlist: Playlist)

    @Query("DELETE FROM playlist_media_cross_ref WHERE playlistId = :playlistId")
    suspend fun deleteCrossRefsForPlaylist(playlistId: Long)

    // --- Playlist Media Cross-reference ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCrossRef(crossRef: PlaylistMediaCrossRef)

    @Query("DELETE FROM playlist_media_cross_ref WHERE playlistId = :playlistId AND mediaTrackId = :mediaTrackId")
    suspend fun deleteCrossRef(playlistId: Long, mediaTrackId: Long)

    @Query("""
        SELECT mt.* FROM media_tracks mt
        INNER JOIN playlist_media_cross_ref ref ON mt.id = ref.mediaTrackId
        WHERE ref.playlistId = :playlistId
        ORDER BY ref.orderIndex ASC
    """)
    fun getTracksForPlaylistFlow(playlistId: Long): Flow<List<MediaTrack>>

    @Query("SELECT COALESCE(MAX(orderIndex), -1) + 1 FROM playlist_media_cross_ref WHERE playlistId = :playlistId")
    suspend fun getNextOrderIndex(playlistId: Long): Int
}
